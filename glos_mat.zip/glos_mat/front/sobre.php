<?php
// Incluindo a conexão com o banco de dados (se necessário)
require_once '../back/db/conexao.php'; // Ajuste o caminho conforme necessário

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre - Glossário Matemático</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Itim&family=Tiny5&family=Varela+Round&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <div class="sidebar">
        <div class="logo">
            <span class="logo-icon">MT</span>
           <a href="index.php " style="text-decoration:none;"><span class="logo-text">Matglossary</span></a> 
        </div>
        <ul class="menu">
            <input type="text" id="searchBar" placeholder="Pesquisar termos..." onkeyup="searchTerms()">
            <li><a href="../back/index.php"><i class="bi bi-bar-chart-line-fill"></i><span>Dashboard</span></a></li>
            <li><a href="sobre.php"><i class="bi bi-info-circle"></i><span>Sobre</span></a></li>
        </ul>
        <button id="btn-add-term" class="btn-add">Adicionar</button>
        <div class="bottom-menu">
            <a href="../back/login.php" class="logout"><span>Login</span></a>
            <div class="mode-switch">
                <label class="switch-container">
                    <input type="checkbox" id="mode-toggle">
                    <span class="slider"></span>
                </label>
            </div>
            <button id="toggle-sidebar-button" class="toggle-sidebar-button">❮</button>
        </div>
    </div>

    
    <div class="main-content">
        <h1>Sobre o Glossário Matemático</h1>

        <div class="row">

        <div class="card">
            <span class="card__title">O que é o Matglossary?</span>
            <p class="card__content">
            O Matglossary é uma plataforma dedicada a fornecer definições claras e explicativas de termos matemáticos. Nosso objetivo é ser um recurso valioso para estudantes, educadores e profissionais da área, promovendo o entendimento de conceitos fundamentais e avançados da matemática.
            </p>
        </div>
        
        <div class="card">
            <span class="card__title">Como Funciona?</span>
            <p class="card__content">
            A plataforma é construída para facilitar o aprendizado da matemática, oferecendo um glossário de termos matemáticos com definições detalhadas. A interface permite que os usuários consultem facilmente os termos e suas definições, e é constantemente atualizada com novos termos para abranger todas as áreas da matemática.
            </p>
        </div>
        
        <div class="card">
            <span class="card__title">Contribuições de Professores</span>
            <p class="card__content">
            Somente professores cadastrados podem adicionar novos termos ou editar definições existentes. Isso garante que o conteúdo do glossário seja sempre preciso e alinhado com as melhores práticas do ensino de matemática. Se você é um professor, pode contribuir com sua experiência para tornar o glossário mais completo.
            </p>
        </div>

        <div class="card">
            <span class="card__title">Objetivo da Plataforma</span>
            <p class="card__content">
            Nosso objetivo é oferecer uma ferramenta útil e acessível para todos que buscam aprimorar seu conhecimento em matemática. Queremos tornar o aprendizado mais fácil e ajudar a consolidar conceitos essenciais de uma maneira simples e direta.
            </p>
        </div>

        <div class="card">
            <span class="card__title">Fale Conosco</span>
            <p class="card__content">
            Se você tiver sugestões ou quiser saber mais sobre como contribuir, entre em contato conosco através da nossa <a href="contato.php">página de contato</a>.
            </p>
        </div>

        </div>

        

    <script>
        const sidebar = document.querySelector('.sidebar');
        const toggleButton = document.getElementById('toggle-sidebar-button');
        const modeToggle = document.getElementById('mode-toggle');

        // Função para alternar o modo escuro
        modeToggle.addEventListener('change', function() {
            if (modeToggle.checked) {
                document.body.classList.add('dark-mode');
                document.querySelector('.sidebar').classList.add('dark-mode');
                document.querySelector('.main-content').classList.add('dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
                document.querySelector('.sidebar').classList.remove('dark-mode');
                document.querySelector('.main-content').classList.remove('dark-mode');
            }
        });

        // Alternar a visibilidade da sidebar
        toggleButton.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            if (sidebar.classList.contains('collapsed')) {
                toggleButton.textContent = '❯';
                document.getElementById('btn-add-term').textContent = '+';
            } else {
                toggleButton.textContent = '❮';
                document.getElementById('btn-add-term').textContent = 'Adicionar';
            }
        });
    </script>
</body>
</html>
