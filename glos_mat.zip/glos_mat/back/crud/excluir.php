<?php
include '../db/conexao.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM termos WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<p class='alert alert-success'>Termo excluído com sucesso!</p>";
    } else {
        echo "<p class='alert alert-danger'>Erro: " . $conn->error . "</p>";
    }
}

if (isset($_POST['termos_selecionados']) && !empty($_POST['termos_selecionados'])) {
    // Pega os IDs dos termos selecionados
    $termosSelecionados = $_POST['termos_selecionados'];

    // Converte o array de IDs para uma string com IDs separados por vírgula
    $ids = implode(",", $termosSelecionados);

    // Cria a query de exclusão para os termos selecionados
    $sql = "DELETE FROM termos WHERE id IN ($ids)";
    
    if ($conn->query($sql) === TRUE) {
        // Exibe mensagem de sucesso
        echo "<p class='alert alert-success'>Termos excluídos com sucesso!</p>";
    } else {
        // Exibe mensagem de erro
        echo "<p class='alert alert-danger'>Erro: " . $conn->error . "</p>";
    }
} else {
    echo "<p class='alert alert-warning'>Nenhum termo selecionado para exclusão.</p>";
}

header("Location: ../index.php");
?>
