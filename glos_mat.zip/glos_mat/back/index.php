<?php include 'db/conexao.php'; ?>
<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Matglossary - ADMIN </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
    <style>
        #btn-irpsite, #btn-add, #btn-pesquisa, #btn-sair:hover, #btn-editar {
            background-color: #4747DB;
            border: 1px solid #4747DB;
            color: #fff;
        }

        #btn-irpsite:hover, 
        #btn-add:hover, 
        #btn-pesquisa:hover {
            background-color: #3333BB;
            border: 1px solid #3333BB;
        }   


        #btn-voltar-topo {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            font-size: 18px;
            background-color: #4747DB;
            color: white;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 17px;
            width: 5%;
            border-radius: 12px;
            justify-content: center;
        }

        #btn-voltar-topo:hover {
            background-color: #333;
        }

        #icon-sair{
            color: #fff;
        }

        @media (max-width: 768px) {

            #btn-voltar-topo {
                width: 5%;
                justify-content: center;
                align-items: center;
                padding: 1%;
            }
    
        }
        
    </style>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-dark shadow-sm">
<div class="container-fluid">
    <a class="navbar-brand" style="color: white;" href="#">Dashboard Matglossary</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul> 
      <a href="../front/index.php">
    <button id="btn-irpsite" class="btn btn-sm btn-primary" style="margin:5px;" type="button"><i class="bi bi-house-fill"></i></button>
</a>
<a href="logout.php">
    <button class="btn btn-sm" id="btn-sair" type="button"><i id="icon-sair" class="bi bi-box-arrow-right"></i></button>
</a>

    </div>
  </div>
    </nav>
<div class="container mt-4">
<?php echo "<h1>Bem-vindo, " . $_SESSION['usuario_nome'] . "</h1>"; ?>        

    <form method="POST" action="index.php" class="my-3">
    <div class="input-group mb-3">
    <input type="text" name="pesquisa" class="form-control" placeholder="Pesquisar termo..." aria-label="Pesquisar termo">
    <button class="btn btn-primary" id="btn-pesquisa"  type="submit">Pesquisar</button>
</div>

    </form>
    <a href="../back/crud/adicionar.php" id="btn-add" class="btn btn-success">Adicionar Novo Termo</a>
    <button href="../back/crud/excluir.php" type="submit" class="btn btn-danger" form="form-delete-selected"><i class="bi bi-trash"></i> Excluir Selecionados</button>

    <?php
    $sql = "SELECT * FROM termos";
    if (isset($_POST['pesquisa'])) {
        $pesquisa = $_POST['pesquisa'];
        $sql .= " WHERE termo LIKE '%$pesquisa%'";
    }
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        
        echo "<form id='form-delete-selected' method='POST' action='crud/excluir.php'>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<div class='card my-3'>";
            echo "<div class='card-body'>";
            echo "<input type='checkbox' name='termos_selecionados[]' value='{$row['id']}' class='form-check-input me-2'>";
            echo "<div class='d-flex justify-content-between align-items-center'>";
            echo "<h2 class='card-title'>{$row['termo']}</h2>";
            echo "<div>";
            echo "<a href='CRUD/editar.php?id={$row['id']}' id='btn-editar' class='btn btn-warning btn-sm' >Editar</a> ";
            echo "<a href='CRUD/excluir.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Deseja excluir este termo?')\">Excluir</a>";
            echo "</div>";
            echo "</div>";
            echo "<p class='card-text'>{$row['definicao']}</p>";
            
            // Exibir a imagem, se houver
            if (!empty($row['imagem'])) {
                echo "<img src='{$row['imagem']}' alt='{$row['termo']}' class='img-fluid' style='max-height: 200px;'>";
            }
            echo "</div></div>";
        }
        
        echo "</form>";
    } else {
        echo "<p class='alert alert-info'>Nenhum termo encontrado.</p>";
    }
    $conn->close();
    ?>
    
</div>
<button id="btn-voltar-topo" title="Voltar ao topo"><i class="bi bi-caret-up-fill"></i></button>
<footer class="bg-dark text-white text-center py-4">
        <p>&copy; 2024 Matglossary | Todos os direitos reservados</p>
    </footer>
    <script>
         // Mostra o botão quando rolar 20px para baixo da parte superior da página
        window.onscroll = function() {
            var btnVoltarTopo = document.getElementById("btn-voltar-topo");
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                btnVoltarTopo.style.display = "block";
            } else {
                btnVoltarTopo.style.display = "none";
            }
        };

        // Rola para o topo da página quando o botão é clicado
        document.getElementById("btn-voltar-topo").addEventListener("click", function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>


